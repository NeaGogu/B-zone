package main

import (
	"encoding/json"
	"net/http"
	"strconv"
)

func (app *application) getBZonePlot(w http.ResponseWriter, r *http.Request) {

	reqBZonePlot, err := strconv.Atoi(r.URL.Query().Get("plot_id"))
	if err != nil || reqBZonePlot < 0 {
		http.Error(w, "Invalid plot id in query", http.StatusBadRequest)
		return
	}

	// send the user id to the model which will return the user's plot IDs
	bZonePlot, err := app.bzoneDbModel.GetPlot(reqBZonePlot)
	if err != nil {
		app.serverError(w, err)
	}

	// encode the output
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(bZonePlot)
	return
}
