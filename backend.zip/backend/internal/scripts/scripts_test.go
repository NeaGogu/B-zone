package scripts

import "testing"

func TestPopulateDatabase(t *testing.T) {

	populateDatabase()

}
