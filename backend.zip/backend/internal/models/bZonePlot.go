package models

import (
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

// GetbZnePlot
//
//	@Description: returns the plot based on the plotID
//	@receiver z
//	@param plotid
//	@return BZonePlot
//	@return error
func (z *BzoneDBModel) GetPlot(plotId int) (PlotModel, error) {
	// get the plots collection
	plotsCollection := z.DB.Collection(PlotCollection)

	// set query filter for the right plot id
	queryFilter := bson.D{{Key: "plot_id", Value: plotId}}

	cur, err := plotsCollection.Find(context.TODO(), queryFilter)
	if err != nil {
		return PlotModel{
			PlotId:        0,
			Name:          "",
			ZoneIds:       nil,
			PlotCreatedAt: time.Time{},
			PlotSavedAt:   time.Time{},
		}, err
	}

	defer cur.Close(context.TODO())
	// @see https://www.mongodb.com/docs/drivers/go/current/fundamentals/crud/read-operations/cursor/#std-label-golang-cursor
	// TODO might want to initialize slice with a zise of cur.BatchSize
	// TODO too many results might cause memory issues... need to investigate -> pagination?
	var bZonePlot PlotModel
	if err = cur.All(context.TODO(), &bZonePlot); err != nil {
		return bZonePlot, err
	}

	return bZonePlot, nil
}

